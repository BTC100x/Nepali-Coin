# DefiDollar
DefiDollar (DUSD) is a stablecoin backed by [Curve Finance](https://www.curve.fi/) LP tokens.

See [blog post](https://medium.com/@atvanguard/a-curvy-defidollar-c249438c154a).

### Development
```
npm run compile
npm run ganache
npm run migrate
npm t
```
